import 'dart:convert';
import 'package:flutter/services.dart';

class WordLoader {
  static Future<List<String>> loadWords(int length) async {
    final path = length == 4
        ? 'assets/four_name_word.json'
        : length == 5
        ? 'assets/five_name_word.json'
        : 'assets/six_name_word.json';
    final raw = await rootBundle.loadString(path);
    final List<dynamic> arr = json.decode(raw);
    return arr.map((e) => e.toString().toLowerCase()).toList();
  }
}
